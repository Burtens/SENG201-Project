/** Chicken subclass contains chicken stats. low value, needs less food */

public class Chicken extends Animals {

    public Chicken() {
        super(50, 50);
    }
}
