/** Sheep subclass contains sheep stats. medium value, needs average amount of food */

public class Sheep extends Animals {

    public Sheep() {
        super(70, 70);
    }
}
