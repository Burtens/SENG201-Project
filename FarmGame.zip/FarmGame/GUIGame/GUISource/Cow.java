/** Cow subclass contains cow stats. high value needs more food */

public class Cow extends Animals {

    public Cow() {
        super(100, 100);
    }
}
