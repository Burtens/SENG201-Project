/** Pig subclass contains pig stats. medium value, needs average amount of food */

public class Pig extends Animals {

    public Pig() {
        super(80, 80);
    }
}
