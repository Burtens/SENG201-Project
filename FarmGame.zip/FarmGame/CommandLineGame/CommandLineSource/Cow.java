public class Cow extends Animals {

    public Cow() {
        super(100, 100);
    }
}
