public class Sheep extends Animals {

    public Sheep() {
        super(70, 70);
    }
}
