public class Pig extends Animals {

    public Pig() {
        super(80, 80);
    }
}
