public class Chicken extends Animals {

    public Chicken() {
        super(50, 50);
    }
}
